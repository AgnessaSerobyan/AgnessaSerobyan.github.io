Original demonstration assets created for Interface Studies.
Project names and team usage labels are fictional.
SVG files can be imported into Figma as editable vectors. They are not native .fig files.
Typography uses system Arial/Helvetica.
